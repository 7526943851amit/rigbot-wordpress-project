<?php
/*
Template Name: Pricing */
get_header();
?>

   <section class="pricing-banner" style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/assets/images/price-bg.png);">
      <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="left-banner-txt">
                  <h2><?php  the_field('banner_pricing_title'); ?></h2>
                  <p><?php  the_field('pricing_banner_desc'); ?></p>
                  <button type="button" class="common-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Check Prices</button>
                </div>
            </div>
            <div class="col-lg-6 text-end">
              <!-- <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/Frame.png" alt=""> -->
             <?php  echo '<img src="' . get_field('frame_image') . '" alt="Frame Image">'; ?>
            </div>
          </div>
        </div>
    </section>
    <section class="pricing pricing-page py-100">
      <div class="container">
        <div class="pricing-box mt-0">
        <div class="row">
  <?php

  if (have_rows('pricing_packs')):
    while (have_rows('pricing_packs')) : the_row();
      $package_title = get_sub_field('package_title');
      $package_features = get_sub_field('package_features');
      $real_time = get_sub_field('real_time');
      $playbacknodes = get_sub_field('playbacknodes');
      $required_hardware = get_sub_field('required_hardware');
      $front_facing = get_sub_field('front_facing');
      $driver_facing = get_sub_field('driver_facing');
      $price = get_sub_field('price');
      $per_truckmonth = get_sub_field('per_truckmonth');
      ?>

      <div class="col-12 col-md-6 col-lg-4">
        <div class="p-in-box" data-aos="flip-left">
          <div class="pri-head-box">
            <h2><?php echo $package_title; ?></h2>
            <p><?php echo $package_features; ?></p>
            <ul>
              <li>
                <span><i class="fa-regular fa-circle-check"></i></span>
                <p><?php echo $real_time; ?></p>
              </li>
              <li>
                <span><i class="fa-regular fa-circle-check"></i></span>
                <p><?php echo $playbacknodes; ?></p>
              </li>
            </ul>
          </div>
          <div class="pri-body-box">
            <h4><?php echo $required_hardware; ?></h4>
            <p><?php echo $front_facing; ?></p>
            <p><?php echo $driver_facing; ?></p>
          </div>
          <div class="pri-foot-box">
            <span class="price"><?php echo $price; ?></span>
            <p><?php echo $per_truckmonth;?></p>
            <a href="javascript:;" class="common-btn">Buy Now</a>
          </div>
        </div>
      </div>
      
    <?php
    endwhile;
  endif;
  ?>
</div>

        </div>
      </div>
    </section>

    <section class="eld-sec">
  <div class="sec-head">
    <h2><?php echo get_field('sec-head'); ?></h2>
  </div>
  <div class="container">
    <?php
    // Check if the repeater field "eld_section" has rows
    if (have_rows('eld_section')):
      // Loop through each row of the repeater field
      while (have_rows('eld_section')) : the_row();
        // Retrieve the values from the sub-fields
        $tlw2_images = get_sub_field('tlw2_images');
        $span_devices = get_sub_field('span_devices');
        $images_bts = get_sub_field('images_bts');
        $span_ltes = get_sub_field('span_ltes');
        $image_wifis = get_sub_field('image_wifis');
        $prdo_top_infos = get_sub_field('prdo-top-infos');
        $prdo_bottom_info = get_sub_field('prdo-top-infos-2');
        $price2775 = get_sub_field('price2775');
        $price_per_truckmonth = get_sub_field('price_per_truckmonth');
        ?>

        <div class="prodduct-boxed-main">
          <div class="prdo-img-sec">
            <img src="<?php echo $tlw2_images; ?>" alt="Frame Image">
            <ul>
              <li>
                <span><?php echo $span_devices; ?></span>
                <span><img src="<?php echo $images_bts; ?>" alt="Frame Image"></span>
              </li>
              <li>
                <span><?php echo $span_ltes; ?></span>
                <span><img src="<?php echo $image_wifis; ?>" alt="Frame Image"></span>
              </li>
            </ul>
          </div>
          <div class="prdo-desc-sec">
            <div class="prdo-top-info">
              <h3><?php echo $prdo_top_infos; ?></h3>
              <p><?php echo $prdo_bottom_info; ?></p>
            </div>
            <div class="prdo-bottom-info">
              <div class="price-d">
                <h4><?php echo $price2775; ?></h4>
                <p><?php echo $price_per_truckmonth; ?></p>
              </div>
              <div class="buy">
                <a href="#" class="common-btn">Buy Now</a>
              </div>
            </div>
          </div>
        </div>

      <?php
      endwhile;
    endif;
    ?>
  </div>
</section>


<section class="eld-sec single-prod py-100">
  <div class="sec-head">
    <h2><?php echo get_field('sec-head_dashcam'); ?></h2>
  </div>
  <div class="container">
    <?php
    // Check if the repeater field "dashcam_section" has rows
    if (have_rows('dashcam_section')):
      // Get the total number of rows in the repeater field
      $total_rows = count(get_field('dashcam_section'));

      // Loop through each row using the for loop
      for ($i = 0; $i < $total_rows; $i++):
        the_row(); // Move the pointer to the current row
        // Retrieve the values from the sub-fields
        $cm_images = get_sub_field('cm_images');
        $ai_dashcampps = get_sub_field('ai_dashcampps');
        $li_1s = get_sub_field('li_1s');
        $li1_images = get_sub_field('li1_images');
        $li_2s = get_sub_field('li_2s');
        $li2_images = get_sub_field('li2_images');
        $li_3s = get_sub_field('li_3s');
        $li3_images = get_sub_field('li3_images');
        $li_4s = get_sub_field('li_4s');
        $li4_images = get_sub_field('li4_images');
        $price4_2775 = get_sub_field('price4_2775');
        $truck4_month = get_sub_field('truck4_month');
        ?>

        <div class="prodduct-boxed-main">
          <div class="prdo-img-sec">
            <img src="<?php echo $cm_images; ?>" alt="tsth1-3_image">
          </div>
          <div class="prdo-desc-sec">
            <div class="prdo-top-info">
              <h3><?php echo $ai_dashcampps; ?></h3>
              <ul class="icon-info-ul">
                <li><span><img src="<?php echo $li1_images; ?>"></span><?php echo $li_1s; ?></li>
                <li><span><img src="<?php echo $li2_images; ?>"></span><?php echo $li_2s; ?></li>
                <li><span><img src="<?php echo $li3_images; ?>"></span><?php echo $li_3s; ?></li>
                <li><span><img src="<?php echo $li4_images; ?>"></span><?php echo $li_4s; ?></li>
              </ul>
            </div>
            <div class="prdo-bottom-info">
              <div class="price-d">
                <h4>"<?php echo $price4_2775 ; ?>"</h4>
                <p><?php echo $truck4_month ;?></p>
              </div>
              <div class="buy">
                <a href="#" class="common-btn">Buy Now</a>
              </div>
            </div>
          </div>
        </div>

      <?php
      endfor;
    endif;
    ?>
  </div>
</section>

  

    <section class="contact-form pb-100">
      <div class="container">
        <div class="row align-items-center">
           <div class="col-lg-5">
          <div class="form-content" data-aos="fade-right">
            <h2><span><?php echo get_field('signup_emailforus');?></h2>
            <div class="con-add-box">
              <div class="call-box" data-aos="fade-right">
              <div class="call-img">
               <?php echo '<img src="'. get_field('pc-icon_image') .'">';?>
              </div>
              <div class="c-u-o">
                <h4><?php echo get_field('contact_us_on');?></h4>
                <p><?php echo get_field("number");?></p>
              </div>
            </div>
            <div class="call-box" data-aos="fade-left">
              <div class="call-img">
              <?php echo '<img src="'. get_field('m-icon_image') .'">';?>
              </div>
              <div class="c-u-o">
                <h4><?php echo get_field('mail_to');?></h4>
                <p><a href="mailto:contactus@rigbot.com"><?php echo get_Field('email');?></a></p>
              </div>
            </div>
            </div>
            <div class="cont-btn" data-aos="fade-down">
              <a href="javascript:;" class="c-u-now"><?php echo get_field('contact_us_now');?><span><i class="fa-solid fa-arrow-down"></i></span></a>
            </div>
          </div>
        </div>
        <div class="col-lg-7">
          <div class="right-form" data-aos="fade-down">
             <form>
              <div class="row">
                <div class="col">
                  <input type="text" class="form-control" placeholder="First Name" name="f-name" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Last Name" name="l-name" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Enter email" name="email" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Phone" name="phone" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Title" name="title" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Company" name="company" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Address" name="address" required>
                </div>
                <div class="col">
                  <input type="text" class="form-control" placeholder="Nummber Of Trucks" name="NOF" required>
                </div>
                <div class="col-12">
                  <textarea class="form-control" rows="10" id="comment" name="text" placeholder="Message"></textarea>
                </div>
              </div>
              <div class="si-up-btn">
                <a href="javascript:;" class="common-btn">sign up now</a>
              </div>
            </form>
          </div>
        </div>
        </div>
      </div>
    </section>

    


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="model-top-logo text-center">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-h.png" alt="">
          <p>Register for RigbotPortal Paid Plan</p>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <div class="paid-form">
              <h5>User Information</h5>
              <form id="myuser" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <div class="form-field">
        <label>User Name</label>
        <input type="text" name="username" placeholder="User Name" class="form-control" required>
      </div>

      <div class="form-field">
        <label>Email Address</label>
        <input type="email" name="email" class="form-control" required>
      </div>

      <div class="form-field">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <input type="hidden" name="action" value="custom_form_submit">
      <input type="submit" name="submit" value="Submit">
    </form>
    <div id="response-message"></div>

            </div>
          </div>
          <!-- <div class="col-lg-6">
            <div class="paid-form">
              <h5>Organization Information</h5>
              <form>
                <div class="form-field">
                  <label>Organization Name</label>
                  <input type="text" name=""  class="form-control">
                </div>
                <div class="form-field">
                  <label>DOT Number</label>
                  <input type="text" name="" class="form-control">
                </div>
                <div class="form-field">
                  <label>Office Phone</label>
                  <input type="text" name=""  class="form-control">
                </div>
                <div class="form-field">
                  <label>Office Contact First Name</label>
                  <input type="text" name=""  class="form-control">
                </div>
                <div class="form-field">
                  <label>Office Contact Last Name</label>
                  <input type="number" name=""  class="form-control">
                </div>
              </form>
            </div>
            <div class="register-sec">
              <a href="#" class="register-btn">Register</a>
              <p>Already have an account?</p>
              <a href="#" class="register-btn login-btn">Login</a>
            </div>
          </div> -->
        </div>
      </div>
    </div>
  </div>
</div>

   <?php


get_footer();
?>
<script>
jQuery(document).ready(function($) {
  $('#myuser').on('submit', function(e) {
    e.preventDefault();

    var formData = $(this).serialize();

    $.ajax({
      type: 'POST',
      url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
      data: formData + '&action=custom_form_ajax_submit',
      success: function(response) {
        $('#response-message').html(response);
        // document.getElementById('response-message').innerHTML="data save successfully";
        if (response.includes('Data inserted successfully')) {
          $('#myuser')[0].reset();
        }
       
      },
      error: function(response) {
        $('#response-message').html('Error occurred. Please try again.');
      }
    });
  });
});
</script>