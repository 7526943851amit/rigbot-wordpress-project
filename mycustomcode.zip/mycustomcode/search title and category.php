<?php
/* Template Name: allpage */
?>

<a href="<?php echo home_url('shop2'); ?>">shop</a>

<main id="primary" class="site-main">
    <div class="search-form-container">
        <form role="search" method="post" class="search-form" action="">
            <label>
                <span class="screen-reader-text">Search by Category And Title:</span>
                <input type="search" class="search-field" placeholder="Search by title…" name="title">
            </label>
            <label>
                <span class="screen-reader-text">Search by Category:</span>
                <input type="search" class="search-field" placeholder="Search by category…" name="category">
            </label>
            <button type="submit" class="search-submit">Search</button>
        </form>
    </div>

    <?php
    if (isset($_POST['title']) || isset($_POST['category'])) {
        $args = array(
            'post_type' => 'post',
        );

        if (isset($_POST['title'])) {
            $search_title = sanitize_text_field($_POST['title']);
            $args['s'] = $search_title;
        }

        if (isset($_POST['category'])) {
            $search_category = sanitize_text_field($_POST['category']);
            $args['category_name'] = $search_category;
        }

        $query = new WP_Query($args);

        if ($query->have_posts()) {
            echo '<h2>Search Results:</h2>';
            while ($query->have_posts()) {
                $query->the_post();
                ?>

                <header class="entry-header">
                    <h2 class="entry-title"><?php the_title(); ?></h2>
                </header>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>

                <?php
            }
        } else {
            echo '<p>No search results found.</p>';
        }
        wp_reset_postdata();
    }
    ?>
</main>
