<?php

// <form id="movie-form" method="post" enctype="multipart/form-data">
// <label for="movie-title">Title:</label>
// <input type="text" id="movie-title" name="movie_title">

// <label for="movie-description">Description:</label>
// <textarea id="movie-description" name="movie_description"></textarea>

// <label for="movie-category">Category:</label>
// <input type="text" id="movie-category" name="movie_category">

// <label for="movie-tag">Tags:</label>
// <input type="text" id="movie-tag" name="movie_tag">

// <label for="movie-featured-image">Featured Image:</label>
// <input type="file" id="movie-featured-image" name="movie_featured_image"/>s
// <input type="submit" value="Submit" name="submit">
// </form>


function save_movie_post() {
    if (isset($_POST['submit'])) {
        // Form submission logic here
        $title = sanitize_text_field($_POST['movie_title']);
        $description = sanitize_text_field($_POST['movie_description']);
        $category = sanitize_text_field($_POST['movie_category']);
        $tags = sanitize_text_field($_POST['movie_tag']);

        // Create a new movie post
        $post_args = array(
            'post_title' => $title,
            'post_content' => $description,
            'post_status' => 'publish',
            'post_type' => 'movie', // Replace with your custom post type slug
            // Add more post type-specific arguments here
        );
   
        $post_id = wp_insert_post($post_args);

        if (!is_wp_error($post_id)) {
            // Assign category and tags
            wp_set_object_terms($post_id, array($category), 'category'); // Replace with your custom taxonomy slug
            wp_set_post_tags($post_id, $tags);

            // Handle featured image upload
            if (!empty($_FILES['movie_featured_image']['name'])) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                require_once(ABSPATH . 'wp-admin/includes/file.php');
                require_once(ABSPATH . 'wp-admin/includes/media.php');

                $attachment_id = media_handle_upload('movie_featured_image', $post_id);

                if (!is_wp_error($attachment_id)) {
                    set_post_thumbnail($post_id, $attachment_id);
                }
            }

            echo "Movie post created successfully!";
        } else {
            echo "Error creating movie post.";
        }
    }
}

add_action('init', 'save_movie_post');


// Custom Post Type function
// Custom Post Type function
function create_custom_post_type() {
    // Labels for the custom post type
    $labels = array(
        'name'               => __( 'Movies', 'text-domain' ),
        'singular_name'      => __( 'Movie', 'text-domain' ),
        // Add other labels as needed
    );

    // Arguments for the custom post type
    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'query_var'           => true,
        'rewrite'             => array( 'slug' => 'movie' ), // Change 'amit' to your desired slug
        'capability_type'     => 'post',
        'has_archive'         => true,
        'hierarchical'        => false,
        'menu_position'       => 5,
        'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
        'menu_icon'           => 'dashicons-video-alt', // Change icon as desired
    );

    // Register the custom post type 'Amit'
    register_post_type( 'movie', $args );

    // Register custom taxonomy 'Genre' for 'Amit' post type
    $taxonomy_labels = array(
        'name'                       => __( 'Genres', 'text-domain' ),
        'singular_name'              => __( 'Genre', 'text-domain' ),
        // Add other labels as needed
    );

    $taxonomy_args = array(
        'labels'            => $taxonomy_labels,
        'hierarchical'      => true, // Set to true for hierarchical taxonomy like categories, false for non-hierarchical like tags.
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'genre' ), // Change 'genre' to your desired slug
    );

    // Register the custom taxonomy 'Genre' for the 'Amit' post type
    register_taxonomy( 'genre', 'movie', $taxonomy_args );
}

// Hook into the init action and call the custom post type function
add_action( 'init', 'create_custom_post_type' );


  

//data insert
function custom_form_ajax_submission() {
    if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'users';

        $username = sanitize_user($_POST['username']);
        $email = sanitize_email($_POST['email']);
        $password = sanitize_text_field($_POST['password']);

        // Check if the user with the same username already exists
        $existing_username = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE user_login = %s", $username)
        );

        // Check if the user with the same email already exists
        $existing_email = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE user_email = %s", $email)
        );

        if ($existing_username || $existing_email) {
            $message = "User with the same ";
            if ($existing_username && $existing_email) {
                $message .= "username and email ";
            } elseif ($existing_username) {
                $message .= "username ";
            } else {
                $message .= "email ";
            }
            $message .= "already exists.";
            echo $message;
        } else {
            // Hash the password using WordPress function
            $hashed_password = wp_hash_password($password);

            $insert_result = $wpdb->insert(
                $table_name,
                array(
                    'user_login' => $username,
                    'user_email' => $email,
                    'user_pass' => $hashed_password,
                )
            );

            if ($insert_result) {
                echo "Data inserted successfully.";
            } else {
                echo "Error inserting data.";
            }
        }
    }
    wp_die();
}

add_action('wp_ajax_custom_form_ajax_submit', 'custom_form_ajax_submission');
add_action('wp_ajax_nopriv_custom_form_ajax_submit', 'custom_form_ajax_submission');


  //end data insert


// Login AJAX handler



add_action('wp_ajax_custom_login', 'custom_login_ajax_handler');
add_action('wp_ajax_nopriv_custom_login', 'custom_login_ajax_handler');

function custom_login_ajax_handler() {
    check_ajax_referer('custom_login_ajax_nonce', 'security');

  
    $username = isset($_POST['username']) ? sanitize_user($_POST['username']) : '';
    $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';


    $user = wp_authenticate($username, $password);


    if (is_wp_error($user)) {
        $error_code = $user->get_error_code();
        $error_message = $user->get_error_message($error_code);
        $response = array(
            'success' => false,
            'data' => array(
                'message' =>   $error_message,
            ),
        );
    } else {
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);  
        do_action('wp_login', $user->user_login, $user); 

        $response = array(
            'success' => true,
            'data' => array(
                'message' => 'login successful',
                // 'redirect_url' => home_url('/'),
            ),
        );
    }
    wp_send_json($response);
}

function enqueue_custom_scripts() {
    wp_enqueue_script('jquery'); // This will enqueue the jQuery library included with WordPress
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');

//   https://gloriathemes.com/wordpress-custom-login-page/

// sharma@gmail.com
// sharma


function add_welcome_message() {
    echo '<script>';
    echo 'console.log("Welcome to my website!");';
    echo '</script>';
}
add_action('wp_head', 'add_welcome_message');



// The rest of the unchanged code...



  
  

  //end login
  

// Styles aur scripts enqueue karein
function twenty_twenty_one_child_enqueue_styles() {
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style'));
}
add_action('wp_enqueue_scripts', 'twenty_twenty_one_child_enqueue_styles');


// Add Ajax


// End Ajax
//create post type 
function create_custom_post_type() {
    // Labels for the custom post type
    $labels = array(
        'name'               => __( 'AI Tools', 'text-domain' ),
        'singular_name'      => __( 'AI Tools', 'text-domain' ),
        // Add other labels as needed
    );

    // Arguments for the custom post type
    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'query_var'           => true,
        'rewrite'             => array( 'slug' => 'ai-tools' ), // Change 'amit' to your desired slug
        'capability_type'     => 'post',
        'has_archive'         => true,
        'hierarchical'        => false,
        'menu_position'       => 5,
        'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
        'menu_icon'           => 'dashicons-video-alt', // Change icon as desired
    );

    // Register the custom post type 'Amit'
    register_post_type( 'ai_tools', $args );

    // Register custom taxonomy 'Genre' for 'Amit' post type
    $taxonomy_labels = array(
        'name'                       => __( 'Ai Category', 'text-domain' ),
        'singular_name'              => __( 'Ai Category', 'text-domain' ),
        // Add other labels as needed
    );

    $taxonomy_args = array(
        'labels'            => $taxonomy_labels,
        'hierarchical'      => true, // Set to true for hierarchical taxonomy like categories, false for non-hierarchical like tags.
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'ai-category' ), // Change 'genre' to your desired slug
    );

    // Register the custom taxonomy 'Genre' for the 'Amit' post type
    register_taxonomy( 'ai-category', 'ai_tools', $taxonomy_args );
    register_taxonomy_for_object_type( 'post_tag', 'ai_tools' );
}

// Hook into the init action and call the custom post type function
add_action( 'init', 'create_custom_post_type' );

//end post type 




// pagination all post type
function custom_pagination_handler() {
    $page = $_POST['page'];

    $args = array(
        'post_type' => 'ai_tools',
        'post_status' => 'publish',
        'posts_per_page' => 3,
        'paged' => $page,
        'orderby' => 'title',
        'order' => 'ASC',
    );

    $loop = new WP_Query($args);

    while ($loop->have_posts()) : $loop->the_post();
        the_title();
        the_content();
    endwhile;

    wp_die();
}

add_action('wp_ajax_custom_pagination', 'custom_pagination_handler');
add_action('wp_ajax_nopriv_custom_pagination', 'custom_pagination_handler');




 //end  pagination all post type



//start fetaured tools category pagination  post type
function custom_featured_tools_pagination_handler() {
    $page = $_POST['page'];

    $args = array(
        'post_type' => 'ai_tools', // Change this to your post type
        'post_status' => 'publish',
        'posts_per_page' => 2, // Display 2 featured tools per page
        'ai-category' => 'Featured Tools', // Replace 'featured' with the category slug
        'paged' => $page,
        'orderby' => 'title',
        'order' => 'ASC',
    );

    $loop = new WP_Query($args);

    while ($loop->have_posts()) : $loop->the_post();
        the_title();
        the_content();
    endwhile;

    wp_die();
}

add_action('wp_ajax_featured_tools_pagination', 'custom_featured_tools_pagination_handler');
add_action('wp_ajax_nopriv_featured_tools_pagination', 'custom_featured_tools_pagination_handler');
 //end  fetaured tools category pagination  post type

?>
