<?php
/*Template Name:Login   */




?>
<div id="login-container">
    <div id="login-message"></div>
    <form id="login-form" method="post">
        <input type="text" name="username" id="username" placeholder="username" required>
        <input type="password" name="password" id="password" placeholder="password" required>
        <input type="submit" value="login">
        <?php wp_nonce_field('custom_login_ajax_nonce', 'security'); ?>
		<!-- // Nonce एक सुरक्षा टोकन है जो WordPress वेबसाइट को उन AJAX और फ़ॉर्म सबमिशन रिक्वेस्ट्स से बचाता है जिन्हें सत्यापित नहीं किया गया है। -->
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    jQuery(document).ready(function ($) {
        $('#login-form').on('submit', function (e) {
            e.preventDefault(); //form ko submit hone se rokta hai je 

            var formData = $(this).serialize();
            var url = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>'; //ajax method ko iss file mein post krta hai

            $.ajax({
                type: 'POST',
                url: url,
                data: 'action=custom_login&' + formData + '&security=<?php echo wp_create_nonce('custom_login_ajax_nonce'); ?>',
                dataType: 'json',
                beforeSend: function () {
                },
                success: function (response) {
                    if (response.success) {
                        // window.location.href = response.data.redirect_url;
                        $('#login-message').html('<p class="success-message">' + response.data.message + '</p>');
                    } else {
                        $('#login-message').html('<p class="error-message">' + response.data.message + '</p>');
                    }
                },
                error: function (xhr, status, error) {
                    console.log(xhr.responseText);
                }
            });
        });
    });
</script>

